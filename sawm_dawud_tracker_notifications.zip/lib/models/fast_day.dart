class FastDay {
  final int dayNumber;
  final DateTime date;
  bool isFasting;
  String notes;

  FastDay({
    required this.dayNumber,
    required this.date,
    required this.isFasting,
    this.notes = '',
  });
}