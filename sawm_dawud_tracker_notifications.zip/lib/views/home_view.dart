import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:ummalqura_calendar/ummalqura_calendar.dart';
import '../controllers/fast_controller.dart';

class HomeView extends StatelessWidget {
  final FastController controller = Get.put(FastController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Sawm Dawud Tracker'),
        centerTitle: true,
      ),
      body: Obx(() => ListView.builder(
            itemCount: controller.fastDays.length,
            itemBuilder: (context, index) {
              final day = controller.fastDays[index];
              UmmalquraCalendar hijriDate = UmmalquraCalendar.fromDate(day.date);
              return Card(
                margin: EdgeInsets.all(8),
                elevation: 3,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                child: ListTile(
                  title: Text('Day \${day.dayNumber}: \${day.date.toLocal().toString().split(' ')[0]}'),
                  subtitle: Text(
                      'Hijri: \${hijriDate.fullDate()} | Status: \${day.isFasting ? 'Fasting' : 'Not Fasting'}'),
                  trailing: Switch(
                    value: day.isFasting,
                    onChanged: (value) => controller.toggleFast(index),
                    activeColor: Colors.green,
                  ),
                ),
              );
            },
          )),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: controller.resetTracker,
        label: Text('Reset'),
        icon: Icon(Icons.refresh),
      ),
    );
  }
}