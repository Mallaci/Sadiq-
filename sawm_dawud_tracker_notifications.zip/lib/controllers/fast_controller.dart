import 'package:get/get.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import '../main.dart';
import '../models/fast_day.dart';

class FastController extends GetxController {
  var fastDays = <FastDay>[].obs;

  @override
  void onInit() {
    super.onInit();
    generateDays();
    scheduleDailyReminder();
  }

  void generateDays() {
    DateTime today = DateTime.now();
    for (int i = 0; i < 30; i++) {
      fastDays.add(FastDay(
        dayNumber: i + 1,
        date: today.add(Duration(days: i)),
        isFasting: i % 2 == 0,
      ));
    }
  }

  void toggleFast(int index) {
    fastDays[index].isFasting = !fastDays[index].isFasting;
    fastDays.refresh();
  }

  void resetTracker() {
    fastDays.clear();
    generateDays();
  }

  void scheduleDailyReminder() async {
    await flutterLocalNotificationsPlugin.zonedSchedule(
      0,
      'Sawm Dawud Reminder',
      'Did you mark your fasting today?',
      _nextInstanceOfEightAM(),
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'fast_reminder_channel',
          'Fast Reminders',
          channelDescription: 'Daily reminder to mark your fast',
          importance: Importance.high,
          priority: Priority.high,
        ),
      ),
      androidAllowWhileIdle: true,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }

  tz.TZDateTime _nextInstanceOfEightAM() {
    final tz.TZDateTime now = tz.TZDateTime.now(tz.local);
    tz.TZDateTime scheduledDate =
        tz.TZDateTime(tz.local, now.year, now.month, now.day, 8);
    if (scheduledDate.isBefore(now)) {
      scheduledDate = scheduledDate.add(Duration(days: 1));
    }
    return scheduledDate;
  }
}